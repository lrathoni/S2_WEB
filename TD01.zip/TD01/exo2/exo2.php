<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8" />
        <title> Exo2 </title>
    </head>
    <body>
        <?php


        #1-2)
            $texte = "Bonsoir";
            $prenom = "Line" ;
            $nom = "Rathonie" ;
            $ville = "Champs-sur-Marne" ;
            $age = "1" ;
            $person['prenom']= $prenom ;
            $person['nom'] = $nom ;
            $person['ville'] = $ville ;
            $person['age'] = $age ;


            if ($person == NULL) {
                echo "there is an error in your code, please check it" ;
            }
            else {
                echo $texte."<br>";
                echo "je m'appelle ".$person['prenom']." ".$personne['nom']."<br>";
                echo "j'habite à ".$person['ville']."<br>";
                if ( $age == "1")
                {
                    echo "et j'ai ".$person['age']." an. <br>" ;
                }
                else {
                echo "et j'ai ".$person['age']." ans. <br>" ;
                }
            }

        # 3)
            $week = ["Lundi", "Mardi", "Veille de race", "Jeudimac", "Post race en TD avec Pascale", "Samedi", "Dimanche"] ;
            echo "Les jours de la semaine : <br>";
            foreach ($week as $value) {
                if ($value == "Dimanche") {
                    echo "$value <br>";
                }
                else {
                echo "$value, ";
                }
            }

        # 4) 
            $person2['prenom']= "Andréa (allias An-an)" ;
            $person2['nom'] = "Guillot(ine)" ;
            $person2['ville'] = "Champs-sur-Marne" ;
            $person2['age'] = "20" ;

            $person3['prenom']= "Clara (allias Picpus)" ;
            $person3['nom'] = "Daigmorte (Deg d'êt'morte)" ;
            $person3['ville'] = "Paris" ;
            $person3['age'] = "22" ;

            $person4['prenom']= "Laurelenn (allias Laulau)";
            $person4['nom'] = "Sangare (sans gare)" ;
            $person4['ville'] = "Champs-sur-Marne" ;
            $person4['age'] = "20";
            
            $people= [$person2,$person3, $person4];

            if ( $people == NULL || empty($people == true)) {
                printf("t'as pas d'amis, je t'offre un curly");
            }
            else {
                echo "<ul>";
                foreach($people as $value) {
               $prenom_list="<li>".$value['prenom']."</li>";
               echo $prenom_list;
                }
                echo "</ul>";
            }
        ?>
    </body>
</html>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8" />
        <title> Hello World en PHP </title>
    </head>
    <body>
        <?php
            $texte = "<h1>J'adore ce que vous faîtes</h1>";
            echo $texte;
        ?>
    </body>
</html>
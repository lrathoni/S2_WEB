<?php
function generate_html_page ($title, $text) {
    $html= <<<HTML
    <!DOCTYPE html>
    <html>
        <head>
            <meta charset="utf-8"/>
            <title>{$title}</title>
        </head>
        <body>
            <h1>{$text}</h1>
        </body>
    </html>
HTML;
    echo $html;
}
?>
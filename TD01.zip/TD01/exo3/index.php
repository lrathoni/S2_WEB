<?php
require_once('html_template.php');
generate_html_page("Hello World", "J'adore ce que vous faîtes");
?>
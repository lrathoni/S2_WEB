<?php
    require_once('data_movies.php');  //récupération des données;
    function render_movie_list($movies, $genre_choice, $mois) {
        $mois_error=0; // condition pour renvoyer "non trouvé"
        $genre_error=0; // condition pour renvoyer "non trouvé"

        foreach ($movies as $movie) { //parcours du tableau de données

            //vérifier si le mois ou le genre sont présents
            if ( substr($movie['date'], -5, 2) == $mois ) { //gestion spécifique pour le mois
                $mois_error=1;// condition pour renvoyer un message "non trouvé"
                }

            if (is_array($movie['genre']) == TRUE) {
                foreach ($movie['genre'] as $genre_value) {
                    if ( $genre_value == $genre_choice ) { //gestion spécifique pour le mois
                    $genre_error=1; // condition pour renvoyer un message "non trouvé"
                    }
                }
            }
            else if (is_array($movie['genre']) == FALSE) { //cas où il y a un seule genre
                if ( $movie['genre'] == $genre_choice ) { //gestion spécifique pour le mois
                    $genre_error=1; // condition pour renvoyer un message "non trouvé"
                }
            }
        }
            
            //renvoie un msg d'erreur si ni le mois ni le genre n'ont été trouvés
            if ( ($genre_error==0) && ($mois_error == 0) ) {
                echo "<div id='notfound'> Il n'y a pas de films dont le mois ou le genre correspondent à votre demande </div>";
                return;
            }



        foreach ($movies as $movie) {

            $TITLE = "<p class='title'>".$movie['title']."<p>"; //définition du titre1

            $mois_presence=0;
            $DATE = "<p class='date'> (".$movie['date'].") </p>";
            if ( substr($movie['date'], -5, 2) == $mois ) { //gestion spécifique pour le mois
                $mois_presence=1;// condition pour afficher le film si le mois correspond
                $DATE = "<p class='date2 date'> (".$movie['date'].") </p>";
            }
            
            $genre_presence=0;
            $genre='Genres : ';
            if (is_array($movie['genre']) == TRUE) { //cas où il y a plusieurs genre
                foreach ($movie['genre'] as $genre_value) {
                    if ( $genre_value == $genre_choice ) { //gestion spécifique pour le mois
                        $genre_presence=1; // condition pour afficher le film si le genre correspond
                    }

                    if ( end($movie['genre']) == $genre_value) { //pour ne pas mettre de virgule à la fin de la liste des genres
                        $genre.=$genre_value;
                    }
                    else {
                        $genre.=$genre_value.", "; //ponctuation de la liste
                    }
                }
            }

            else if (is_array($movie['genre']) == FALSE) { //cas où il y a un seule genre
                if ( $movie['genre'] == $genre_choice ) { //gestion spécifique pour le mois
                    $genre_presence=1; // condition pour afficher le film si le genre correspond;
                }
                $genre="Genre : ".$movie['genre'];
            }

            $GENRE = "<p class='genre'>".$genre."</p>";

            if ($genre_presence == 1) {
                $GENRE = "<p class='genre2 genre'>".$genre."</p>";
            }              
                      
            //même remarques pour le(s) producteur(s)
            if (is_array($movie['director']) == TRUE) {
                $director='Directors : ';
                foreach ($movie['director'] as $director_value) {
                    if ( end($movie['director']) == $director_value) {
                        $director.=$director_value;
                    }
                    else {
                        $director.=$director_value.", ";
                    }
                }
            }
            else if (is_array($movie['director']) == FALSE){
                $director="Director : ".$movie['director'];
            }
            $DIRECTOR = "<p class='director'>".$director."</p>";


            if ( ($mois_presence == 1) || ($genre_presence == 1) ) {
                echo "<div class='movie'>".$TITLE.$DATE.$GENRE.$DIRECTOR."</div>";
            }
        }
    }
?>
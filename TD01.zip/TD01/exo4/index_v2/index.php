<!DOCTYPE html>
    <html>
        <head>
            <meta charset="utf-8"/>
            <title>Movies</title>
            <link rel="stylesheet" href="normalize.css">
            <link rel="stylesheet" href="style.css">
            <link href="https://fonts.googleapis.com/css?family=Monoton" rel="stylesheet"> 
            <link href="https://fonts.googleapis.com/css?family=Lobster|Rokkitt" rel="stylesheet"> 
        </head>
        <body>
            <h1>MOVIES</h1>
            <div id='struct'>
                <?php
                    require_once('render_movie_list.php');
                    render_movie_list($movies, 'Adventure', '03');

                ?>

            </div>
        </body>
    </html>
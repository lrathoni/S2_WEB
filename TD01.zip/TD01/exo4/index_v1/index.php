<!DOCTYPE html>
    <html>
        <head>
            <meta charset="utf-8"/>
            <title>Movies</title>
            <link rel="stylesheet" href="normalize.css">  
            <link rel="stylesheet" href="style.css">
            <link href="https://fonts.googleapis.com/css?family=Monoton" rel="stylesheet"> 
            <link href="https://fonts.googleapis.com/css?family=Lobster|Rokkitt" rel="stylesheet"> 
        </head>
        <body>
        <div>
            <h1>MOVIES</h1>
            <div id='struct'>
                <?php
                    require_once('data_movies.php');  //récupération des données
                    foreach ($movies as $movie) { //parcours du tableau de données
                        $TITLE = "<p class='title'>".$movie['title']."<p>"; //définition du titre
                        $DATE = "<p class='date'> (".$movie['date'].") </p>";
                                    //<img id='fleche' class='arrow' src='fleche.png'>"; //définition de la date
                        if ( substr($movie['date'], -5, 2) == '02' ) { //gestion spécifique pour le 2ème mois
                            $DATE = "<p class='date2 date'> (".$movie['date'].") </p>";
                        }

                        $genre='Genres : ';
                        $comedy=0 ;

                        if (is_array($movie['genre']) == TRUE) { //cas où il y a plusieurs genre
                            foreach ($movie['genre'] as $genre_value) {
                                if ($genre_value == 'Comedy') {
                                    $comedy=1;
                                }

                                if ( end($movie['genre']) == $genre_value) { //pour ne pas mettre de virgule à la fin de la liste des genres
                                    $genre.=$genre_value;
                                }
                                else {
                                $genre.=$genre_value.", "; //ponctuation de la liste
                                }
                            }
                        }
                        else if (is_array($movie['genre']) == FALSE) { //cas où il y a un seule genre
                            $genre="Genre : ".$movie['genre'];
                            if ($movie['genre'] == 'Comedy') {
                                $comedy=1;
                            }
                        }
                        
                        //gestion du genre comedie
                        $GENRE = "<p class='genre'>".$genre."</p>";

                        if ($comedy ==1 ) { 
                            $GENRE = "<p class='comedy genre'>".$genre."</p>";
                        }
                        
                        //même remarques pour le(s) producteur(s)
                        if (is_array($movie['director']) == TRUE) {
                            $director='Directors : ';
                            foreach ($movie['director'] as $director_value) {
                                if ( end($movie['director']) == $director_value) {
                                    $director.=$director_value;
                                }
                                else {
                                $director.=$director_value.", ";
                                }
                            }
                        }
                        else if (is_array($movie['director']) == FALSE){
                            $director="Director : ".$movie['director'];
                        }
                        $DIRECTOR = "<p class='director'>".$director."</p>";

                        echo "<div class='movie'>".$TITLE.$DATE.$GENRE.$DIRECTOR."</div>";
                    }
                ?>
            </div>
        </div>
    </body>
</html>